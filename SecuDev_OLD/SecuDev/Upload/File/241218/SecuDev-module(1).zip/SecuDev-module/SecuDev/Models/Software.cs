﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecuDev.Models
{
    public class Software
    {
        public int SoftwareID { get; set; }
        public string SoftwareName { get; set; }

    }
}