﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecuDev.Models
{
    public class Category
    {
        public int CID { get; set; }
        public string CategoryName { get; set; }
        public string BackgroundColor { get; set; }
        public string FontColor { get; set; }

    }
}